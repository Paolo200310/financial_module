
{
    "name": "Módulo Financiero",
    "version": "1.0",
    "category": "Accounting",
    "summary": "Gestiona ventas, compras y presupuestos",
    "depends": ["sale", "purchase"],
    "data": [
        "security/ir.model.access.csv",
        "views/financial_view.xml"
    ],
    "installable": True,
    "application": True,
}
