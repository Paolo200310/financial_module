
from odoo import models, fields, api

class FinancialSummary(models.Model):
    _name = 'financial.summary'
    _description = 'Resumen Financiero'

    name = fields.Char(string="Nombre", default="Resumen Financiero")
    sale_total = fields.Float(string="Total de Ventas", compute="_compute_totals")
    purchase_total = fields.Float(string="Total de Compras", compute="_compute_totals")
    budget = fields.Float(string="Presupuesto")
    total_budget = fields.Float(string="Presupuesto Final", compute="_compute_totals")

    @api.depends('budget')
    def _compute_totals(self):
        for record in self:
            sale_total = self.env['sale.order'].search_read([], ['amount_total'])
            purchase_total = self.env['purchase.order'].search_read([], ['amount_total'])
            record.sale_total = sum([s['amount_total'] for s in sale_total])
            record.purchase_total = sum([p['amount_total'] for p in purchase_total])
            record.total_budget = (record.sale_total + record.budget) - record.purchase_total
